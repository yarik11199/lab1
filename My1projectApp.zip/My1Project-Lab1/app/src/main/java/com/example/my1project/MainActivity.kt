package com.example.my1project

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // +
        val plusButton: ImageButton = findViewById(R.id.plusImageButton)
        plusButton.setOnClickListener { updateCounterValue(add=true) }

        // -
        val minusButton: ImageButton = findViewById(R.id.minusImageButton)
        minusButton.setOnClickListener { updateCounterValue(add=false) }

        // Счетчик
        val valueText: TextView = findViewById(R.id.valueTextView)
        valueText.text = resources.getText(R.string.default_value_text)

        // Ввод
        val stepText: EditText = findViewById(R.id.stepEditText)
        stepText.setText(resources.getText(R.string.default_step_text))
        stepText.doOnTextChanged { _, _, _, _ ->
            if (isValidValueText()){
                plusButton.isEnabled = true
                minusButton.isEnabled = true
            } else {
                plusButton.isEnabled = false
                minusButton.isEnabled = false
            }
        }

        // 2 окно
        val secondActivityButton: Button = findViewById(R.id.secondActivityButton)
        secondActivityButton.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("value", valueText.text.toString())
            startActivity(intent)
        }
    }

    private fun isValidValueText(): Boolean {
        val stepText: EditText = findViewById(R.id.stepEditText)
        return when {
            stepText.text.isBlank() -> {
                stepText.error = resources.getText(R.string.step_blank_error)
                false
            }
            stepText.text.contains(regex = Regex("[^0-9]")) -> {
                stepText.error = resources.getText(R.string.step_not_digits_error)
                false
            }
            else -> {
                true
            }
        }
    }

    private fun updateCounterValue(add: Boolean) {
        val valueText: TextView = findViewById(R.id.valueTextView)
        val stepText: EditText = findViewById(R.id.stepEditText)
        val value: Int = valueText.text.toString().toInt()
        var step: Int = stepText.text.toString().toInt()
        step = if (add) step else -step
        valueText.text = (value + step).toString()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putCharSequence("value", findViewById<TextView>(R.id.valueTextView).text)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        findViewById<TextView>(R.id.valueTextView).text = savedInstanceState.getCharSequence("value")
    }
}